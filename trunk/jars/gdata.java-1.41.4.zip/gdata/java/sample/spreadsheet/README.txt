Google Spreadsheets data API Java Sample - README.txt
-----------------------------------------------------

Google Spreadsheets has multiple ways of access, and thus we have
multiple sample applications.

In cells/, there is a small sample application that shows
demonstrates positional getting and setting of formulas and values.

In list/, there is a small sample application where you can modify
your spreadsheet data almost like a database.

Finally, in gui/, there is a sample that you can use to see potential
ways that Google Spreadsheets Data API could be used to develop a
real, full-featured application.

